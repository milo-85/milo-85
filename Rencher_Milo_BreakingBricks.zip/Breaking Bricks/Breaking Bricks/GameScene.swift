//
//  GameScene.swift
//  Breaking Bricks
//
//  Created by Mobile on 5/1/26.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    var entities = [GKEntity]()
    var graphs = [String : GKGraph]()
    
    let noCategory: UInt32 = 0;
    let paddleCategory: UInt32 = 0b1;
    let ballCategory: UInt32 = 0b1 << 1;
    let brickCategory: UInt32 = 0b1 << 2;
    let wallCategory: UInt32 = 0b1 << 3;
    
    var targetX: CGFloat = 0
    
    var hitCount: Int = 0
    var numBalls: Int = 1
    
    
    private var lastUpdateTime : TimeInterval = 0
    
    override func sceneDidLoad() {
        
        self.physicsWorld.contactDelegate = self
        
        view?.showsPhysics = false
        
        self.lastUpdateTime = 0
        
        spawnBricks()
        
        if let scene = SKScene(fileNamed: "Paddle.sks"),
           let paddle = scene.childNode(withName: "paddle") as? SKSpriteNode {
            
            let ellipseSize = CGSize(width: 100, height: 30)
            
            let ellipsePath = CGPath(ellipseIn: CGRect(x: -ellipseSize.width / 2, y: -ellipseSize.height / 2, width: ellipseSize.width,height: ellipseSize.height), transform: nil)
            
            paddle.physicsBody = SKPhysicsBody(polygonFrom: ellipsePath)

            paddle.position = CGPoint(x: 0, y: -400)
            paddle.move(toParent: self)

            paddle.physicsBody?.categoryBitMask = paddleCategory
            paddle.physicsBody?.contactTestBitMask = ballCategory
            paddle.physicsBody?.collisionBitMask = noCategory
        }
        
        let ball = self.childNode(withName: "ball") as! SKSpriteNode
        
        ball.physicsBody?.categoryBitMask = ballCategory
        ball.physicsBody?.contactTestBitMask = brickCategory | wallCategory
        
        let bottom = self.childNode(withName: "bottom") as! SKSpriteNode
        
        bottom.physicsBody?.categoryBitMask = wallCategory
        bottom.physicsBody?.contactTestBitMask = ballCategory
        
    }
    
    func spawnBricks() {
        let rows = 10
        let cols = 18
        let spaceRatio: CGFloat = 8.0 // ratio of brick width to spacing
        let brickWidth: CGFloat = self.frame.width / ((CGFloat(cols) + 1) / spaceRatio + CGFloat(cols))
        let brickHeight: CGFloat = brickWidth / 2.0
        let spacing: CGFloat = brickWidth / spaceRatio
 
        let startX = self.frame.minX + spacing + brickWidth / 2
        let startY = self.frame.maxY + spacing - brickHeight / 2
        
        for row in 0..<rows{
            for col in 0..<cols{
                let brick = SKSpriteNode(imageNamed: "brick.png")
//                brick.anchorPoint = .zero
                brick.physicsBody = SKPhysicsBody(rectangleOf: brick.size)
                
                brick.scale(to: CGSize(width: brickWidth, height: brickHeight))
                brick.physicsBody?.isDynamic = false
                
                let x = startX + CGFloat(col) * (brickWidth + spacing)
                let y = startY - CGFloat(row) * (brickHeight + spacing)

                brick.position = CGPoint(x: x, y: y)
                brick.name = "brick"
                
                self.addChild(brick)
                
                brick.physicsBody?.categoryBitMask = brickCategory
                brick.physicsBody?.contactTestBitMask = ballCategory
                brick.physicsBody?.isDynamic = false
            }
        }

    }
    
    func spawnButton() {
        let button = SKSpriteNode(color: .systemBlue, size: CGSize(width: 180, height: 60))
        button.name = "spawnButton"
        button.position = CGPoint(x: frame.midX, y: frame.midY)
        button.zPosition = 100

        let label = SKLabelNode(text: "Restart")
        label.fontName = "AvenirNext-Bold"
        label.fontSize = 24
        label.verticalAlignmentMode = .center
        label.horizontalAlignmentMode = .center
        label.name = "spawnButtonLabel"

        button.addChild(label)
        addChild(button)
    }
    
    func removeBricks() {
        enumerateChildNodes(withName: "brick") { node, _ in
            node.removeFromParent()
        }
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        let bodyA = contact.bodyA
        let bodyB = contact.bodyB

        if bodyA.categoryBitMask == ballCategory && bodyB.categoryBitMask == brickCategory {
            bodyB.node?.removeFromParent()
            hitCount += 1
        } else if bodyA.categoryBitMask == brickCategory && bodyB.categoryBitMask == ballCategory {
            bodyA.node?.removeFromParent()
            hitCount += 1
        }
        
        if bodyA.categoryBitMask == ballCategory && bodyB.categoryBitMask == wallCategory {
            bodyA.node?.removeFromParent()
            numBalls -= 1
            if numBalls == 0 {
                spawnButton()
            }
            
        } else if bodyA.categoryBitMask == wallCategory && bodyB.categoryBitMask == ballCategory {
            bodyB.node?.removeFromParent()
            numBalls -= 1
            if numBalls == 0 {
                spawnButton()
            }
        }
        
        if hitCount == 10 {
            respawnBall()
            hitCount = 0
        }
    }
    
    func respawnBall() {
        numBalls += 1
        
        let newBall = SKSpriteNode(imageNamed: "ball")
        newBall.position = CGPoint(x: 5, y: 315)
        newBall.physicsBody = SKPhysicsBody(circleOfRadius: newBall.size.width / 2)
        newBall.physicsBody?.categoryBitMask = ballCategory
        newBall.physicsBody?.contactTestBitMask = brickCategory | wallCategory
        newBall.physicsBody?.velocity = CGVector(dx: 600, dy: -600)
        newBall.physicsBody?.friction = 0
        newBall.physicsBody?.linearDamping = 0
        newBall.physicsBody?.angularDamping = 0
        newBall.physicsBody?.restitution = 1
        newBall.physicsBody?.allowsRotation = false
        addChild(newBall)
    }
    
    override func didMove(to view: SKView) {
        backgroundColor = .black
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        physicsWorld.gravity = CGVector(dx: 0, dy: 0)
    }
    
    func touchDown(atPoint pos : CGPoint) {
        
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        
    }
    
    func touchUp(atPoint pos : CGPoint) {
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first,
              let paddle = childNode(withName: "paddle") else { return }

        let location = touch.location(in: self)
        let halfWidth = paddle.frame.width / 2
        let minX = -size.width / 2 + halfWidth
        let maxX = size.width / 2 - halfWidth

        paddle.position.x = max(minX, min(maxX, location.x))
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)

        let tappedNode = atPoint(location)

        if tappedNode.name == "spawnButton" || tappedNode.parent?.name == "spawnButton" {
            removeBricks()
            spawnBricks()
            respawnBall()
            hitCount = 0
            tappedNode.parent?.removeFromParent()
            tappedNode.removeFromParent()
        }
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered

        
        // Initialize _lastUpdateTime if it has not already been
        if (self.lastUpdateTime == 0) {
            self.lastUpdateTime = currentTime
        }
        
        // Calculate time since last update
        let dt = currentTime - self.lastUpdateTime
        
        // Update entities
        for entity in self.entities {
            entity.update(deltaTime: dt)
        }
        
        self.lastUpdateTime = currentTime


    }
}
